$gamerule doMobSpawning $(v)
