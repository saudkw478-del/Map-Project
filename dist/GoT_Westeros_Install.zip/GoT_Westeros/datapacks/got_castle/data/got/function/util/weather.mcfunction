$weather $(v)
