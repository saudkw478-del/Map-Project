$gamerule doDaylightCycle $(v)
