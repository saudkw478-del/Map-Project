summon minecraft:vindicator ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:vindicator ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:vindicator ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:vindicator ~-9 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:vindicator ~-3 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:vindicator ~3 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 2.. run summon minecraft:vindicator ~9 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 2.. run summon minecraft:vindicator ~15 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 3.. run summon minecraft:vindicator ~21 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 3.. run summon minecraft:vindicator ~27 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 4.. run summon minecraft:vindicator ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 4.. run summon minecraft:vindicator ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 5.. run summon minecraft:vindicator ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 5.. run summon minecraft:vindicator ~-9 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 6.. run summon minecraft:vindicator ~-3 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 6.. run summon minecraft:vindicator ~3 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 7.. run summon minecraft:vindicator ~9 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 7.. run summon minecraft:vindicator ~15 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 8.. run summon minecraft:vindicator ~21 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 8.. run summon minecraft:vindicator ~27 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~-9 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~-3 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~3 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~9 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:zombie ~15 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 2.. run summon minecraft:zombie ~21 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 2.. run summon minecraft:zombie ~27 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 3.. run summon minecraft:zombie ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 3.. run summon minecraft:zombie ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 4.. run summon minecraft:zombie ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 4.. run summon minecraft:zombie ~-9 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 5.. run summon minecraft:zombie ~-3 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 5.. run summon minecraft:zombie ~3 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 6.. run summon minecraft:zombie ~9 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 6.. run summon minecraft:zombie ~15 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 7.. run summon minecraft:zombie ~21 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 7.. run summon minecraft:zombie ~27 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 8.. run summon minecraft:zombie ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 8.. run summon minecraft:zombie ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:creeper ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:creeper ~-9 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:creeper ~-3 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
summon minecraft:creeper ~3 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 2.. run summon minecraft:creeper ~9 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 3.. run summon minecraft:creeper ~15 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 4.. run summon minecraft:creeper ~21 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 5.. run summon minecraft:creeper ~27 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 6.. run summon minecraft:creeper ~-27 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 7.. run summon minecraft:creeper ~-21 ~ ~60 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #players got_g matches 8.. run summon minecraft:creeper ~-15 ~ ~56 {Tags:["got_enemy","got_new"],PersistenceRequired:1b}
execute if score #fallen got_g matches 1.. run function got:wave/bonus
