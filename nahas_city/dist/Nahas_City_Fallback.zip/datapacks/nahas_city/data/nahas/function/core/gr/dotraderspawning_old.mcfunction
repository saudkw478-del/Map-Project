$gamerule doTraderSpawning $(v)
