$gamerule keepInventory $(v)
