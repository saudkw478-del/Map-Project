$gamerule doInsomnia $(v)
