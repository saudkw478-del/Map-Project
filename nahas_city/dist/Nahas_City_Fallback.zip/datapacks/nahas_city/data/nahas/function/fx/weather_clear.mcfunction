weather clear
