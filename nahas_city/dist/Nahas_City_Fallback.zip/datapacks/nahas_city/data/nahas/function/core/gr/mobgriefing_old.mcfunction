$gamerule mobGriefing $(v)
