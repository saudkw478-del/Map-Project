weather thunder
