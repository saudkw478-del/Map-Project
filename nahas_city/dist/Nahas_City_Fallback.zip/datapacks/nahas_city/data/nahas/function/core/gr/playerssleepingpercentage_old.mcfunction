$gamerule playersSleepingPercentage $(v)
