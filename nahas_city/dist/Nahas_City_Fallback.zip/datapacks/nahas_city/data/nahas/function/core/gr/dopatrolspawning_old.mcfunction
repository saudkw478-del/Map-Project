$gamerule doPatrolSpawning $(v)
