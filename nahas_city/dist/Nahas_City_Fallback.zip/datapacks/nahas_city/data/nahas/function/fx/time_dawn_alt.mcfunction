time set day
